import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: HexColor('#F1216B'),
        accentColor: Colors.green,
        backgroundColor: HexColor('#3c2158'),
        textTheme: GoogleFonts.rubikTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
      routes: {
        '/': (context) => Awal(),
      },
    );
  }
}

class Awal extends StatelessWidget {
  MediaQueryData queryData;
  @override
  Widget build(BuildContext context) {
    queryData = MediaQuery.of(context);
    return Scaffold(
      body: SafeArea(
          child: Center(
            child: Container(
              width: double.infinity,
              color: Theme.of(context).backgroundColor,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
                    child: Text("Excited?!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28, color: Colors.white), textAlign: TextAlign.start, ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
                    child: Text("You should be!!", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24, color: Colors.white), textAlign: TextAlign.start,),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text("Sign in if you already have an account with us", style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12, color: Colors.white), textAlign: TextAlign.start,),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                    child: RaisedButton(
                      child: Text("Sign In", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Login();
                        }));
                      },
                      color: Colors.white,
                      textColor: Colors.black,
                      elevation: 10,
                      padding: EdgeInsets.all(16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24)
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text("Or sign up if you are new!", style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12, color: Colors.white), textAlign: TextAlign.start,),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                    child: RaisedButton(
                      child: Text("Sign Up", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) {
                          return Login();
                        }));
                      },
                      color: Colors.white,
                      textColor: Colors.black,
                      elevation: 10,
                      padding: EdgeInsets.all(16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24)
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
      ),
    );
  }
}

class Login extends StatelessWidget {
  MediaQueryData queryData;
  TextEditingController _email_controller = TextEditingController();
  TextEditingController _password_controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    queryData = MediaQuery.of(context);
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      body: SafeArea(
          child: Container(
            color: HexColor('#0b0645'),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 32),
                  child: Center(child: ClipRRect(
                      borderRadius: BorderRadius.circular(80.0),
                      child: Image.asset('assets/profile.jpeg', width: 150, height: 150, fit: BoxFit.cover,))),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 24, left: 16, right: 16),
                  child: Text("Log In", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28, color: Colors.white), textAlign: TextAlign.center,),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: TextField(
                    keyboardType: TextInputType.emailAddress,
                    textAlign: TextAlign.start,
                    decoration: InputDecoration(
                      hintText: 'Email Address',
                      hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.white,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        borderSide: BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        borderSide: BorderSide(color: Colors.white),
                      ),
                    ),
                    controller: _email_controller,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: TextField(
                    textAlign: TextAlign.start,
                    keyboardType: TextInputType.visiblePassword,
                    decoration: InputDecoration(
                      hintText: 'Password',
                      hintStyle: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold),
                      filled: true,
                      fillColor: Colors.white,
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        borderSide: BorderSide(color: Colors.white),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        borderSide: BorderSide(color: Colors.white),
                      ),
                    ),
                    controller: _password_controller,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
                  child: RaisedButton(
                    child: Text("LOGIN"),
                    onPressed: () {
                      if(_password_controller.text.isEmpty) {
                        Flushbar(
                          title:  "Password kosong",
                          message:  "Masukkan password terlebih dahulu!",
                          duration:  Duration(seconds: 3),
                        )..show(context);
                      }
                      if(_email_controller.text.isEmpty) {
                        Flushbar(
                          title:  "Email kosong",
                          message:  "Masukkan email terlebih dahulu!",
                          duration:  Duration(seconds: 3),
                        )..show(context);
                      }
                      if(!_email_controller.text.isEmpty && !_password_controller.text.isEmpty){
                        Flushbar(
                          title:  "Login Berhasil",
                          message:  "email ${_email_controller.text} telah berhasil masuk!",
                          duration:  Duration(seconds: 3),
                        )..show(context);
                      }
                    },
                    color: HexColor('#1c784c'),
                    textColor: Colors.white,
                    elevation: 10,
                    padding: EdgeInsets.all(16),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24)
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 24, left: 16, right: 16, top: 16.0),
                  child: Text("Forgot password?", style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12, color: Colors.white70), textAlign: TextAlign.center,),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 16.0),
                  child: Text("Register Here", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white70), textAlign: TextAlign.center,),
                ),
              ],
            ),
          )
      ),
    );
  }
}