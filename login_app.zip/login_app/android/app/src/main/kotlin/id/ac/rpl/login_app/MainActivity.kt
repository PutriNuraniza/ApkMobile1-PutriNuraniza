package id.ac.rpl.login_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
